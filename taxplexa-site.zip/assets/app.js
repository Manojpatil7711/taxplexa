
const $=id=>document.getElementById(id),v=id=>parseFloat($(id).value)||0;
const cur=()=>$('cur')?$('cur').value:'£';
const f=n=>cur()+n.toLocaleString('en-GB',{minimumFractionDigits:2,maximumFractionDigits:2});
const row=(l,n,b)=>`<div class="r${b?' big':''}"><span>${l}</span><span>${f(n)}</span></div>`;
const T={
emi(){const P=v('amt'),r=v('rate')/1200,n=v('yrs')*12;if(!P||!n)return'Enter an amount and a term.';
const m=r?P*r*Math.pow(1+r,n)/(Math.pow(1+r,n)-1):P/n,t=m*n;return row('Monthly payment',m,1)+row('Total repaid',t)+row('Total interest',t-P)},
comp(){let b=v('p'),c=v('c'),r=v('rate')/1200,y=v('yrs'),dep=b;for(let i=0;i<y*12;i++){b=b*(1+r)+c;dep+=c}
return row('Final balance',b,1)+row('Total paid in',dep)+row('Interest earned',b-dep)},
uktax(){const g=v('gross');if(!g)return'Enter your gross salary.';let pa=12570;if(g>100000)pa=Math.max(0,pa-(g-100000)/2);
const x=Math.max(0,g-pa),tax=Math.min(x,37700)*.2+Math.min(Math.max(x-37700,0),125140-37700)*.4+Math.max(x-125140,0)*.45;
const ni=Math.max(0,Math.min(g,50270)-12570)*.08+Math.max(0,g-50270)*.02,net=g-tax-ni;
return row('Take-home pay (year)',net,1)+row('Take-home (month)',net/12)+row('Income Tax',tax)+row('National Insurance',ni)+row('Personal Allowance used',pa)},
sdlt(){const p=v('price'),t=$('type').value;let B=[[125000,0],[250000,.02],[925000,.05],[1500000,.10],[Infinity,.12]];
if(t=='ftb'&&p<=500000)B=[[300000,0],[500000,.05]];if(t=='add')B=B.map(b=>[b[0],b[1]+.05]);
let tax=0,lo=0;for(const[h,r]of B){if(p>lo)tax+=(Math.min(p,h)-lo)*r;lo=h}
return row('Stamp Duty (SDLT)',tax,1)+`<div class="r"><span>Effective rate</span><span>${p?(tax/p*100).toFixed(2):0}%</span></div>`},
vat(){const a=v('amt'),r=v('rate')/100;if($('mode').value=='add')return row('Net',a)+row('Tax',a*r)+row('Total',a*(1+r),1);
const n=a/(1+r);return row('Net',n,1)+row('Tax',a-n)+row('Gross',a)},
};
function calc(k){$('out').innerHTML=T[k]()}
let L=0;function addLine(){L++;const t=$('lines');t.insertAdjacentHTML('beforeend',`<tr><td><input id="d${L}" placeholder="Description"></td><td><input id="q${L}" type="number" value="1" style="width:70px"></td><td><input id="u${L}" type="number" placeholder="0.00" style="width:110px"></td></tr>`)}
function makeInv(){const tx=v('tax')/100;let s=0,h='';for(let i=1;i<=L;i++){const q=v('q'+i),u=v('u'+i),d=$('d'+i).value;if(!d&&!u)continue;s+=q*u;h+=`<tr><td>${esc(d)}</td><td>${q}</td><td>${f(u)}</td><td>${f(q*u)}</td></tr>`}
$('out').innerHTML=`<h2>Invoice ${esc($('no').value)}</h2><p><b>From:</b> ${esc($('from').value).replace(/\n/g,'<br>')}<br><b>To:</b> ${esc($('to').value).replace(/\n/g,'<br>')}<br><b>Date:</b> ${esc($('date').value)}</p><table class="inv"><tr><th>Item</th><th>Qty</th><th>Price</th><th>Amount</th></tr>${h}</table>`+row('Subtotal',s)+row('Tax',s*tx)+row('Total due',s*(1+tx),1)+`<button class="noprint" onclick="window.print()">Print or save as PDF</button>`}
const esc=s=>s.replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
if($('lines')){addLine();addLine();addLine()}
